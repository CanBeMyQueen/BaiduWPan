(function(){
	$(".new_create").on("click",createFiles);
	var data2 = [];var data = [];
	var onOff = true;


//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

function createFiles(){
	if(onOff){
		var str = '';
		var serial_number = +new Date();
		data.push({"id":serial_number});
		str = `<li data-id=${serial_number}>
					<span>
						<em class="glyphicon glyphicon-folder-close"></em>
					</span>
					<p class="file_name">new name</p>
					<input type="text" class="file_text" >
				</li>`;

			$("#files_all_list").append(str);
			setFileName(serial_number);
			localStorage.setItem("id",JSON.stringify(data));
		// for(var attr in data){
		// 	console.log(getTime(data[attr].id));
		// }
	}
}
function setFileName(fileId){
	var $lis = $("#files_all_list").find("li");
	for(var i=0;i<$lis.length;i++){
		$($lis[i]).on("click",function(){
			$(".none_ele").css("display","block");
			$($lis).find("span").removeClass("active");
			$(this).find("span").addClass("active");
			
		})
		if($lis[i].getAttribute("data-id") == fileId){
			var $liThis = $($lis[i]).find("p");
			$($liThis).css("display","none");
			$($lis[i]).find("input").css("display","block").focus().val("新建文件夹").on("blur",function(){
				console.log(this);
				var val = $(this).val();
				for(var i=0;i<data.length;i++){
					if(data[i] === val){
						onOff = false;
						return;
					}
				}
				onOff = true;
				data.push(val);
				$(this).css("display","none");
				$($liThis).css("display","block").html(val);
			});
		}
	}
}
function getTime(time){
	var date = new Date(time);
	var year = date.getFullYear(),
		month = add0(date.getMonth()+1),
		day = add0(date.getDate()),
		hours = add0(date.getHours()),
		min = add0(date.getMinutes()),
		sec = add0(date.getSeconds());
	return year + "-" + month + "-" + day + " " + hours + ":" + min + ":" + sec;
}
function add0(nub){
	return nub<10?"0"+nub:""+nub;
}


/*
百度云盘=>需求: 
	1:创建文件夹{
		点击新建文件夹,添加一个文件夹,先不显示name,需设置初始化的name,失去焦点提交name,
		name重复的不允许提交,并给出提示(最好是运动版的提示),	文件名给出限制字数
	}
	2:重命名{
		重新命名,点击一下文件夹,给加选择的class,并且菜单list出现,点击重命名就可以修改名字,
		修改名字合法才能提交,否者提示不合法格式,名字字数有限制
	}
	3:移动{
		点选移动的时候,出现一个选项框,选中需要移动到的文件夹目录下面,点击提交,
		就可以把文件提交到相对应的文件夹下面了,
	}
	4:点选显示样式{
		横向的显示样式,方块式的显示方式,分别显示不同的风格,操作也是相应的,横向式的显示创建日期,
	}
	5:点击刷新能刷新数据{
		刷新数据,但移动到不同目录下的数据不变,
	}
	6:点击正在下载/正在上传/传输完成{
		切换不同的页面,
	}
	7:选中多条数据之后{
		选中多条数据之后,将没有重命名这一选项,
	}
	8:选择显示方式为方块模式{
		每一项都有一个checked的选框,
		添加排序方式,分别是:/文件名/大小/日期,开关式的选择,
		有一个隔行变色的功能,
		有一个鼠标移入的hover效果
	}
	9:
*/














})(window);