(function(){
	//阻止默认事件
	$(document).on("mousedown",function(ev){
		ev.preventDefault();
	});
	leftNavsHoverClick();//侧边navs 全部文件,正在下载,正在上传,传输完成
	//filesMenuHover();//files文件更多按钮menu的hover效果
	changeColor();//files文件隔行变色效果
	var num = 1;
	var search = window.location.search.substr(1);
	var fValue = getSearch("f")||"files";
	//获取search值
	function getSearch(key){
		if(!search){
			return false;
		}else{
			var arr = search.split("=");
			if(arr[0] === key){
				return arr[1];
			}
		}
	}
	if(search){
		var lis = $("#left_a_file").find("li");
		$.each(lis,function(i,e){
			if($(e).attr("data-search").split("=")[1] == getSearch("f")){
				$(lis).eq(i).addClass("active");
				createHeaderNavs(fValue);
			}
		});
	}else{
		$("#left_a_file").find("li").eq(0).addClass("active");
		createHeaderNavs(fValue);
	}
	// 文件名排序,大小,修改时间
	$(".right_list_bottom").find("li").on("mousedown",function(){
		$(this).addClass("active");
	}).on("mouseup",function(){
		$(this).removeClass("active");
	});
	//files list center navs menu
	filesListCenterNavsMenu();
	function filesListCenterNavsMenu(){
		$("#files_list_all").find("li").on("mouseover",function(){
			$(this).find(".row_lists").css("display","block");
			$(this).find(".row_lists_more").on("click",function(){
				$(this).next().css("display","block");
			})
		}).on("mouseout",function(){
			$(this).find(".row_lists").css("display","none");
			//$(".row_lists_menu").css("display","none")
		});
	}

	$(".new_create").on("click",function(){
		num++;
		$("#files_list_all").append(createFiles(num));
		changeColor();
		filesListCenterNavsMenu();
	});
	//console.log(+new Date(getTime()))
	
		rowActive();

})();//activeBg
function rowActive(){
	$(".row_list").each(function(i,e){
		$(e).on("click",function(){

			$(this).find(".checkeds").attr("checked",true);
		});
		// $(e).find(".checkeds").attr("checked",true)
		// console.log($(e).find(".checkeds").attr("checked",false));
	});
}



function createFiles(num){
	var time = +new Date(getTime())*Math.random();
	console.log(time,getTime());
	var lis = `<li class="row_list">
					<label for="${time}">
						<div class="row_list_name">
							<input type="checkbox" class="checkeds" id="${time}">
							<em class="glyphicon glyphicon-folder-close"></em>
							<p>
								<span class="file_name">新建文件夹(${num})</span>
								<input type="text" class="file_text">
							</p>
							<nav class="row_lists">
								<a href="javascript:;" class="glyphicon glyphicon-cloud-download row_lists_down"></a>
								<a href="javascript:;" class="glyphicon glyphicon-trash row_lists_delete"></a>
								<a href="javascript:;" class="glyphicon glyphicon-move"></a>
								
							</nav> 
						</div>
						<div class="row_list_size">
							<span>-</span>
						</div>
						<div class="row_list_time">
							<span>${getTime()}</span>
						</div>
					</label>
				</li>`;
	return $(lis);
}
function leftNavsHoverClick(){
	$("#left_a_file").find("li").stop().on("click",function(){
		window.location.search = $(this).attr("data-search");
		$("#left_a_file").find("li").removeClass("active");
		$(this).addClass("active");
	});
}
function filesMenuHover(){
	$(".row_lists_menu").on("mouseout",function(){
		$(this).find("span").removeClass("active");
	}).find("span").on("mouseover",function(){
		$(this).addClass("active").siblings("span").removeClass("active");
	});
}
function changeColor(){
	$(".row_list:odd").css("background","#F9F9F9");
	$(".row_list").on("mouseover",function(){
		$(this).addClass("active");
	}).on("mouseout",function(){
		$(this).removeClass("active");
	});
}
function createHeaderNavs(key){
	if(key === "files"){
		var filesVal = ` <li class="active" id="files">
						<a href="javascript:;"><span class="glyphicon glyphicon-cloud-upload"></span>上传<input type="file" id="file"></a>
					</li>
					<li class="new_create">
						<a href="javascript:;"><span class="glyphicon glyphicon-folder-close"></span>新建文件夹</a>
					</li>
					<li class="none_ele">
						<a href=""><span class="glyphicon glyphicon-cloud-download"></span>下载</a>
					</li>
					<li class="none_ele">
						<a href=""><span class="glyphicon glyphicon-trash"></span>删除</a>
					</li>
					<li id="head_list_more" class="none_ele">
						<a href="javascript:;">更多操作<span class="glyphicon glyphicon-chevron-down"></span></a>
						<nav>
							<a href="javascript:;">复制</a><a href="javascript:;">移动</a><a href="javascript:;">重命名</a>
						</nav>
					</li>`;
		var filesVal2 = `<div class="head_right_navs">
						<nav>
							<a href="col" class="glyphicon glyphicon-list active" title="横向式排序"></a>
							<a href="row" class="glyphicon glyphicon-th-large" title="方块式排序"></a>
						</nav>
					</div>
					<div class="refresh">
						<a href="javascript:;" class="glyphicon glyphicon-repeat" title="刷新"></a>
					</div>`;
		var filesVal3 = `<ul class="right_list_bottom">
							<li>
								<input type="checkbox" class="chechedAll">
								<span class="file_names">文件名</span>
							</li>
							<li>
								<span>大小</span>
							</li>
							<li>
								<span>修改时间</span>
							</li>
						</ul>`;
		$(".right_list_top").find("a").html("全部文件");
		$(".head_list_navs").html(filesVal);
		$(".head_list").append($(filesVal2));
		$(".right_list_head").append($(filesVal3));
		//$("#files_list_all").addClass("filesBg");
		//刷新页面按钮
		$(".head_list").find(".refresh").on("click",function(){
			window.location.search = "f=files";
		});
	}else if(key === "upload"){
		create("uploadBg")
	}else if(key === "download"){
		create("downloadBg")
	}else if(key === "accomplish"){
		var accomplish1 = `<li>
							<a href="javascript:;"><span class="glyphicon glyphicon-trash"></span>清除全部记录</a>
						</li>`;
		var accomplish2 = `<ul class="right_list_bottom_upload">
							<li>
								<input type="checkbox" class="chechedAll">
								<span class="file_names">文件名</span>
							</li>
							<li>
								<span>大小</span>
							</li>
							<li>
								<span>状态</span>
							</li>
							<li>
								<span>操作</span>
							</li>
						</ul>`;
		$(".head_list_navs").html(accomplish1);
		$(".right_list_head").append($(accomplish2));
		$(".right_list_top").find("a").html("传输完成");
		$("#files_list_all").html("").attr("class","accomplishBg");
	}
}
function create(Class){
	var createNavs = `<li>
							<a href="javascript:;"><span class="glyphicon glyphicon-pause"></span>全部暂停</a>
						</li>
						<li>
							<a href="javascript:;"><span class="glyphicon glyphicon-play"></span>全部开始</a>
						</li>
						<li>
							<a href="javascript:;"><span class="glyphicon glyphicon-trash"></span>全部删除</a>
						</li>`;
		var createFiles = `<ul class="right_list_bottom_upload">
							<li>
								<input type="checkbox" class="chechedAll">
								<span class="file_names">文件名</span>
							</li>
							<li>
								<span>大小</span>
							</li>
							<li>
								<span>状态</span>
							</li>
							<li>
								<span>操作</span>
							</li>
						</ul>`;
		$(".right_list_head").append($(createFiles));
		$(".right_list_top").find("a").html("正在下载");
		$(".head_list_navs").html(createNavs);
		$("#files_list_all").html("").attr("class",Class);
}
function getTime(){
	var date = new Date();
	var year = date.getFullYear(),
		month = add0(date.getMonth()+1),
		day = add0(date.getDate()),
		hours = add0(date.getHours()),
		min = add0(date.getMinutes()),
		sec = add0(date.getSeconds());
	return year + "-" + month + "-" + day + " " + hours + ":" + min + ":" + sec;
}
function add0(nub){
	return nub<10?"0"+nub:""+nub;
}



/*


*/

/*
百度云盘=>需求: 
	1:创建文件夹{
		点击新建文件夹,添加一个文件夹,先不显示name,需设置初始化的name,失去焦点提交name,
		name重复的不允许提交,并给出提示(最好是运动版的提示),	文件名给出限制字数
	}
	2:重命名{
		重新命名,点击一下文件夹,给加选择的class,并且菜单list出现,点击重命名就可以修改名字,
		修改名字合法才能提交,否者提示不合法格式,名字字数有限制
	}
	3:移动{
		点选移动的时候,出现一个选项框,选中需要移动到的文件夹目录下面,点击提交,
		就可以把文件提交到相对应的文件夹下面了,
	}
	4:点选显示样式{
		横向的显示样式,方块式的显示方式,分别显示不同的风格,操作也是相应的,横向式的显示创建日期,
	}
	5:点击刷新能刷新数据{
		刷新数据,但移动到不同目录下的数据不变,
	}
	6:点击正在下载/正在上传/传输完成{
		切换不同的页面,
	}
	7:选中多条数据之后{
		选中多条数据之后,将没有重命名这一选项,
	}
	8:选择显示方式为方块模式{
		每一项都有一个checked的选框,
		添加排序方式,分别是:/文件名/大小/日期,开关式的选择,
		有一个隔行变色的功能,
		有一个鼠标移入的hover效果
	}
*/
