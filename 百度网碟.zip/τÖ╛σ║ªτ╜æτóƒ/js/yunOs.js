(function(){$(function(window){var dirTimer=null;$(".bottom_dir").on("mouseover",f_over).on("mouseout",f_out);$(".user_float_list").on("mouseover",f_overUser).on("mouseout",f_out);$("#head_list_more").on("mouseover",f_overMenu).on("mouseout",f_outNav).find("nav").on("mouseover",fn_overNav).on("mouseout",fn_outNav);function f_out(){dirTimer=setTimeout(function(){$(".user_float_list").css("display","none")},300)}function f_over(){clearTimeout(dirTimer);$(".user_float_list").css("display","block")}function f_overUser(){clearTimeout(dirTimer)}function f_overMenu(){clearTimeout(dirTimer);$(this).find("nav").css("display","block")}function f_outNav(){var $This=$(this).find("nav");dirTimer=setTimeout(function(){$($This).css("display","none")},300)}function fn_overNav(){clearTimeout(dirTimer);$(this).css("display","block")}function fn_outNav(){clearTimeout(dirTimer);dirTimer=setTimeout(function(){$(this).css("display","none")},300)}})})();

// (function(){
// 	$(function(window){
// 		var dirTimer = null;

// 		$(".bottom_dir").on("mouseover",f_over).on("mouseout",f_out);
// 		$(".user_float_list").on("mouseover",f_overUser).on("mouseout",f_out);
// 		$("#head_list_more").on("mouseover",f_overMenu).on("mouseout",f_outNav).find("nav").on("mouseover",fn_overNav).on("mouseout",fn_outNav);
// ////////////////////////////////////////////////////////////////////////////////////

// 		function f_out(){
// 			dirTimer = setTimeout(function(){
// 				$(".user_float_list").css("display","none");
// 			},300);
// 		}
// 		function f_over(){
// 			clearTimeout(dirTimer);
// 			$(".user_float_list").css("display","block");
// 		}
// 		function f_overUser(){
// 			clearTimeout(dirTimer);
// 		}

// 		function f_overMenu(){
// 			clearTimeout(dirTimer);
// 			$(this).find("nav").css("display","block");
// 		}
// 		function f_outNav(){
// 			var $This = $(this).find("nav");
// 			dirTimer = setTimeout(function(){
// 				$($This).css("display","none");
// 			},300);
// 		}

// 		function fn_overNav(){
// 			clearTimeout(dirTimer);
// 			$(this).css("display","block");
// 		}
// 		function fn_outNav(){
// 			clearTimeout(dirTimer);
// 			dirTimer = setTimeout(function(){
// 				$(this).css("display","none")
// 			},300);
// 		}
// 	});
// })();